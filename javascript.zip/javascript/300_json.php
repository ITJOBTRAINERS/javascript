<?php
//$con=mysqli_connect("localhost","root","","javascript_db");
$mysqli = new mysqli("localhost", "root", "", "javascript_db");

/* check connection */
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}

/* Select queries return a resultset */

$query = "SELECT Name, Email, Phone FROM Personal LIMIT 10";

if ($result = $mysqli->query($query)) {

    /* fetch associative array */
    while ($row[] = $result->fetch_assoc()) {
    }
    $result->close();

    /* free result set */
}

	echo json_encode($row);

    /* free result set */


?>