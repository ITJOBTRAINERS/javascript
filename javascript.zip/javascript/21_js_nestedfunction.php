<!DOCTYPE html>
<html>
<head><title>for loop</title></head>
<body>
  <h2>FOR LOOP EXECUTION</h2>
  <script>
  var complicated=function(){
    var f=function(y){
      return y*3+1
    };
    return f(f(x));
  };
  var y=complicated(2);

  </script>
  
</body>
</html>
