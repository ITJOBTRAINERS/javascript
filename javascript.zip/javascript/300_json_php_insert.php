<?php
$string = file_get_contents("result.json");
$data = json_decode($string,true);
//print_r($data); exit;
$con = mysqli_connect('localhost','root','','javascript_db');
//echo $data[0]['sno'];
foreach ($data as $key => $val)
{
    $sno = $val['sno'];
	$name = $val['name'];
	$course = $val['course'];
	$sql = "insert into students(sno,name,course) values('".$sno."','".$name."','".$course."')";
	$result = mysqli_query($con,$sql);
	if($result)
		echo "Inserted";
	else 
		echo "Not Inserted";
}
?>